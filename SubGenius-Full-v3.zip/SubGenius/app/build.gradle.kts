plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.subgenius.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.subgenius.app"
        minSdk = 26
        targetSdk = 35
        // رقم الإصدار يزيد تلقائياً مع كل تشغيل لـ GitHub Actions (مطلوب لرفع تحديثات Google Play)
        versionCode = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionName = "1.3.0"
        // مكتبة FFmpeg المُصانة (16KB) تنشر arm64-v8a فقط، وهو معمار كل الهواتف الحديثة
        ndk { abiFilters += "arm64-v8a" }
    }

    signingConfigs {
        create("release") {
            val keystorePath = System.getenv("KEYSTORE_FILE")
            if (keystorePath != null && file(keystorePath).exists()) {
                storeFile = file(keystorePath)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            // R8 متوقف عمداً: JNA وVosk وFFmpegKit تستخدم JNI/Reflection
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (signingConfigs.getByName("release").storeFile != null) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }

    // لا نقسّم اللغات في الـ AAB حتى تبقى الواجهة عربية/إنجليزية على كل الأجهزة
    bundle { language { enableSplit = false } }

    packaging {
        resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" }
        jniLibs { pickFirsts += "**/libc++_shared.so" }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.8.4")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // FFmpeg: نسخة مُصانة (بديل arthenica بعد إيقافه) — تدعم 16KB وSDK 35. إن فشل التحميل ضع .aar في app/libs
    implementation("dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.7")
    implementation("com.arthenica:smart-exception-java:0.2.1")
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.aar"))))

    // Vosk 0.3.75 يدعم صفحات الذاكرة 16KB (مطلوب في Google Play)
    implementation("com.alphacephei:vosk-android:0.3.75")
    // Whisper (whisper.cpp) للتعرف على اللهجات — إن لم يُحمَّل 1.0.0 جرّب 0.1.2
    implementation("dev.ffmpegkit-maintained:whisper-android:1.0.0")
    implementation("net.java.dev.jna:jna:5.17.0@aar")
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("androidx.media3:media3-exoplayer:1.5.0")
    implementation("androidx.media3:media3-ui:1.5.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.9.0")
}
