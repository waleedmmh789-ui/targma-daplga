package com.subgenius.app.engine

/** الأحجام نسبة إلى PlayResY=288 (يتم تكبيرها تلقائياً حسب دقة الفيديو) */
data class SubtitleStyle(
    val fontSize: Int = 22,
    val primaryColor: String = "&H00FFFFFF",
    val backColor: String = "&H80000000",
    val outline: Int = 2,
    val borderStyle: Int = 3,
    val marginV: Int = 14,
    val fontName: String = "Roboto"
) {
    companion object {
        fun fontNameFor(lang: String): String = when (lang.lowercase()) {
            "ar", "fa", "ur" -> "Noto Naskh Arabic"
            "zh" -> "Noto Sans CJK SC"
            "ja" -> "Noto Sans CJK JP"
            else -> "Roboto"
        }
    }
}
