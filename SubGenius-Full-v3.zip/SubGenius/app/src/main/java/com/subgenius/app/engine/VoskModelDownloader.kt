package com.subgenius.app.engine

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

data class VoskModelInfo(val lang: String, val label: String, val url: String, val dirName: String, val size: String)

object VoskModelDownloader {
    // الأحجام والروابط من https://alphacephei.com/vosk/models — إن تغيّر رابط سيظهر "HTTP 404" عند التنزيل
    private const val BASE = "https://alphacephei.com/vosk/models/"
    val models = listOf(
        VoskModelInfo("ar", "العربية", BASE + "vosk-model-ar-mgb2-0.4.zip", "vosk-ar", "~320MB"),
        VoskModelInfo("en", "English", BASE + "vosk-model-small-en-us-0.15.zip", "vosk-en", "~40MB"),
        VoskModelInfo("fr", "Français", BASE + "vosk-model-small-fr-0.22.zip", "vosk-fr", "~41MB"),
        VoskModelInfo("es", "Español", BASE + "vosk-model-small-es-0.42.zip", "vosk-es", "~39MB"),
        VoskModelInfo("de", "Deutsch", BASE + "vosk-model-small-de-0.15.zip", "vosk-de", "~45MB"),
        VoskModelInfo("ru", "Русский", BASE + "vosk-model-small-ru-0.22.zip", "vosk-ru", "~45MB"),
        VoskModelInfo("tr", "Türkçe", BASE + "vosk-model-small-tr-0.3.zip", "vosk-tr", "~35MB"),
        VoskModelInfo("zh", "中文", BASE + "vosk-model-small-cn-0.22.zip", "vosk-zh", "~42MB"),
        VoskModelInfo("ja", "日本語", BASE + "vosk-model-small-ja-0.22.zip", "vosk-ja", "~48MB")
    )

    fun info(lang: String): VoskModelInfo? = models.firstOrNull { it.lang == lang }

    fun getModelPath(context: Context, lang: String): String? {
        val m = info(lang) ?: return null
        return findModelDir(File(context.filesDir, m.dirName))?.absolutePath
    }

    private fun findModelDir(dir: File): File? {
        if (!dir.exists()) return null
        if (File(dir, "conf").exists() || File(dir, "am").exists()) return dir
        dir.listFiles()?.forEach { c ->
            if (c.isDirectory && (File(c, "conf").exists() || File(c, "am").exists())) return c
        }
        return null
    }

    suspend fun downloadAndUnzip(context: Context, lang: String, onProgress: (Int) -> Unit): Result<String> =
        withContext(Dispatchers.IO) {
            val m = info(lang) ?: return@withContext Result.failure(Exception("لغة غير مدعومة"))
            val zipFile = File(context.cacheDir, "vosk_${m.lang}.zip")
            try {
                val conn = URL(m.url).openConnection() as HttpURLConnection
                conn.connectTimeout = 20000; conn.readTimeout = 30000
                conn.connect()
                if (conn.responseCode != 200) throw Exception("HTTP ${conn.responseCode} — تحقق من رابط النموذج")
                val total = conn.contentLengthLong
                var downloaded = 0L
                conn.inputStream.use { input ->
                    FileOutputStream(zipFile).use { output ->
                        val buf = ByteArray(8192); var n: Int
                        while (input.read(buf).also { n = it } != -1) {
                            output.write(buf, 0, n); downloaded += n
                            if (total > 0) onProgress(((downloaded * 100) / total).toInt().coerceIn(0, 99))
                        }
                    }
                }
                val target = File(context.filesDir, m.dirName)
                if (target.exists()) target.deleteRecursively()
                target.mkdirs()
                ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
                    var e = zis.nextEntry
                    while (e != null) {
                        val out = File(target, e.name)
                        if (!out.canonicalPath.startsWith(target.canonicalPath + File.separator))
                            throw SecurityException("unsafe path")
                        if (e.isDirectory) out.mkdirs() else {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { fos ->
                                val b = ByteArray(8192); var k: Int
                                while (zis.read(b).also { k = it } != -1) fos.write(b, 0, k)
                            }
                        }
                        zis.closeEntry(); e = zis.nextEntry
                    }
                }
                zipFile.delete()
                val actual = findModelDir(target) ?: throw Exception("بنية النموذج غير متوقعة")
                onProgress(100)
                Result.success(actual.absolutePath)
            } catch (e: Exception) {
                Result.failure(e)
            } finally {
                runCatching { zipFile.delete() }
            }
        }
}
