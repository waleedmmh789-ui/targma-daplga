package com.subgenius.app.engine

import java.io.File
import java.io.RandomAccessFile
import kotlin.math.sqrt

/**
 * يقدّر طبقة صوت المتكلم (التردد الأساسي F0) من صوت PCM خام s16le 16kHz mono، على الجهاز وبلا إنترنت.
 * طريقة الارتباط الذاتي (autocorrelation) على مقاطع صوتية قصيرة، ثم الوسيط.
 */
object VoiceEstimator {
    private const val RATE = 16000
    private const val FRAME = 800          // 50ms
    private const val STEP = 960           // نأخذ مقطعاً كل 60ms لتوفير الوقت
    private const val MIN_LAG = 40         // 400Hz
    private const val MAX_LAG = 213        // 75Hz
    private const val MAX_VOICED = 300

    /** يرجع الوسيط بالهرتز، أو null إن لم يجد كلاماً واضحاً */
    fun medianPitchHz(pcm: File, maxSeconds: Int = 120): Double? {
        val bytes = minOf(pcm.length(), maxSeconds.toLong() * RATE * 2).toInt() / 2 * 2
        if (bytes < FRAME * 2 * 4) return null
        val raw = ByteArray(bytes)
        RandomAccessFile(pcm, "r").use { it.readFully(raw) }
        val n = bytes / 2
        val x = FloatArray(n)
        for (i in 0 until n) {
            x[i] = ((raw[2 * i + 1].toInt() shl 8) or (raw[2 * i].toInt() and 0xFF)).toFloat()
        }

        // عتبة الطاقة: نتجاهل الصمت والضجيج الخافت
        val rms = ArrayList<Float>()
        var pos = 0
        while (pos + FRAME <= n) {
            var s = 0.0
            for (i in pos until pos + FRAME) s += x[i] * x[i]
            rms.add(sqrt(s / FRAME).toFloat())
            pos += STEP
        }
        if (rms.isEmpty()) return null
        val sorted = rms.sorted()
        val thr = maxOf(sorted[(sorted.size * 0.6).toInt().coerceAtMost(sorted.size - 1)], 200f)

        val f0s = ArrayList<Double>()
        val acf = FloatArray(MAX_LAG + 2)
        var idx = 0
        pos = 0
        while (pos + FRAME <= n && f0s.size < MAX_VOICED) {
            if (rms[idx] >= thr) {
                var r0 = 0.0
                for (i in pos until pos + FRAME) r0 += x[i] * x[i]
                if (r0 > 0) {
                    var best = 0f
                    for (lag in MIN_LAG..MAX_LAG + 1) {
                        var s = 0.0
                        val end = pos + FRAME - lag
                        for (i in pos until end) s += x[i] * x[i + lag]
                        // نعوّض نقص عدد العينات كلما زاد التأخير
                        val v = (s / r0 * FRAME / (FRAME - lag)).toFloat()
                        acf[lag] = v
                        if (lag <= MAX_LAG && v > best) best = v
                    }
                    if (best >= 0.5f) {
                        // نأخذ أصغر تأخير قريب من القمة لتفادي خطأ الضعف (octave)
                        for (lag in MIN_LAG + 1..MAX_LAG) {
                            val v = acf[lag]
                            if (v >= best * 0.9f && v >= acf[lag - 1] && v >= acf[lag + 1]) {
                                f0s.add(RATE.toDouble() / lag)
                                break
                            }
                        }
                    }
                }
            }
            idx++
            pos += STEP
        }
        if (f0s.size < 8) return null
        f0s.sort()
        return f0s[f0s.size / 2]
    }
}
